using System.Text.Json.Serialization;

namespace ProiectPOO
{
    public class TipBilet
    {
        [JsonInclude]
        public string Nume { get; init; }
        
        [JsonInclude]
        public decimal Pret { get; init; }
        
        [JsonInclude]
        public int NrLocuri { get; private set; }
        
        [JsonInclude]
        public int CapacitateTotala { get; init; }

        
        public TipBilet() { }

        public TipBilet(string nume, decimal pret, int locuri)
        {
            Nume = nume;
            Pret = pret;
            NrLocuri = locuri;
            CapacitateTotala = locuri;
        }

        public bool VindeUnLoc()
        {
            if (NrLocuri > 0)
            {
                NrLocuri--;
                return true;
            }
            return false;
        }

        public void ElibereazaUnLoc()
        {
            if (NrLocuri < CapacitateTotala)
            {
                NrLocuri++;
            }
        }

        public override string ToString() => $"{Nume}: {Pret} RON ({NrLocuri}/{CapacitateTotala} disp)";
    }
}