namespace ProiectPOO
{
    public class TipBilet
    {
        public string Nume { get; init; }
        public decimal Pret { get; init; }
        public int NrLocuri { get; private set; }
        public int CapacitateTotala { get; init; }

        public TipBilet() { }

        public TipBilet(string nume, decimal pret, int locuri)
        {
            Nume = nume;
            Pret = pret;
            NrLocuri = locuri;
            CapacitateTotala = locuri;
        }

        public bool VindeUnLoc()
        {
            if (NrLocuri > 0)
            {
                NrLocuri--;
                return true;
            }
            return false;
        }

        public void ElibereazaUnLoc()
        {
            if (NrLocuri < CapacitateTotala)
            {
                NrLocuri++;
            }
        }

        public override string ToString() => $"{Nume}: {Pret} RON ({NrLocuri}/{CapacitateTotala} disp)";
    }
}