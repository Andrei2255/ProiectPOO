namespace ProiectPOO
{
    public interface IEventRepository
    {
        List<Eveniment> GetAll();
        void Add(Eveniment ev);
        void Update(Eveniment ev);
        void Remove(Eveniment ev);
    }
}