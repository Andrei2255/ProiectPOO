namespace ProiectPOO
{
    public class Client : Utilizator
    {
        public Client(string nume, string email, string parola) 
            : base(nume, email, parola, "Client")
        {
        }
    }
}