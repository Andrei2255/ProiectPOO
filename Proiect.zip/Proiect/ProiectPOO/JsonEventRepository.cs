using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace ProiectPOO
{
    public class JsonEventRepository : IEventRepository
    {
        private readonly string _filePath = "date_evenimente.json"; 
        private List<Eveniment> _cache;
        private readonly ILogger<JsonEventRepository> _logger;
        
        private readonly JsonSerializerOptions _options = new JsonSerializerOptions
        {
            WriteIndented = true,
            IncludeFields = true,
            PropertyNameCaseInsensitive = true 
        };

        public JsonEventRepository(ILogger<JsonEventRepository> logger)
        {
            _logger = logger;
            _cache = IncarcaDinFisier();
        }

        public List<Eveniment> GetAll() => _cache;

        public void Add(Eveniment ev)
        {
            _cache.Add(ev);
            Salveaza();
            _logger.LogInformation($"Creat: {ev.Nume}");
        }

        public void Update(Eveniment ev)
        {
            Salveaza();
            _logger.LogInformation($"Actualizat: {ev.Nume}");
        }

        public void Remove(Eveniment ev)
        {
            _cache.Remove(ev);
            Salveaza();
            _logger.LogWarning($"Sters: {ev.Nume}");
        }

        private void Salveaza()
        {
            try
            {
            
                string json = JsonSerializer.Serialize(_cache, _options);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex) 
            { 
                _logger.LogError(ex, "Eroare la scrierea in fisier JSON."); 
            }
        }

        private List<Eveniment> IncarcaDinFisier()
        {
            if (!File.Exists(_filePath)) 
            {
                return new List<Eveniment>();
            }

            try
            {
                string json = File.ReadAllText(_filePath);
                var date = JsonSerializer.Deserialize<List<Eveniment>>(json, _options);
                return date ?? new List<Eveniment>();
            }
            catch (Exception ex) 
            { 
                
                _logger.LogError(ex, "Nu am putut incarca datele din Json! Se porneste cu lista goala.");
                return new List<Eveniment>(); 
            }
        }
    }
}