using Microsoft.Extensions.Logging;

namespace ProiectPOO
{
    public class ClientService
    {
        private readonly IEventRepository _repo;
        private readonly ILogger<ClientService> _logger;
        private string _numeLogat; 

        public ClientService(IEventRepository repo, ILogger<ClientService> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        public void Meniu(string numeClient)
        {
            _numeLogat = numeClient; 

            while (true)
            {
                Console.WriteLine($"\n Meniu client: {_numeLogat.ToUpper()}");
                Console.WriteLine("1. Cauta Evenimente si Cumpara");
                Console.WriteLine("2. Biletele mele (Vezi / Anuleaza)");
                Console.WriteLine("3. Istoric Evenimente Trecute");
                Console.WriteLine("0. Inapoi (Delogare)");
                Console.Write("Optiune: ");
                
                string opt = Console.ReadLine() ;
                
                if (opt == "0") break;
                else if (opt == "1") CautaSiCumpara();
                else if (opt == "2") BileteleMele();
                else if (opt == "3") IstoricTrecut();
                else Console.WriteLine("Optiune invalida.");
            }
        }

        private void CautaSiCumpara()
        {
            var list = _repo.GetAll();
            Console.WriteLine("\n Cautare ");
            Console.Write("Cauta (Nume/Locatie) [Enter pentru toate]: ");
            string filtru = Console.ReadLine() .ToLower();

            var rezultate = list.FindAll(e => 
                (e.Nume.ToLower().Contains(filtru) || e.Locatie.ToLower().Contains(filtru)) 
                && e.Status == "Programat" 
                && e.Data > DateTime.Now);

            if (rezultate.Count == 0)
            {
                Console.WriteLine("Nu s-au gasit evenimente viitoare.");
                return;
            }

            foreach (var ev in rezultate)
            {
                Console.WriteLine($"\nEveniment: {ev}");
                foreach (var tip in ev.TipuriBilete) Console.WriteLine($"   * {tip}");
            }

            Console.Write("\nScrie numele evenimentului pentru a cumpara [sau Enter pentru inapoi]: ");
            string numeEv = Console.ReadLine() ;
            if (string.IsNullOrEmpty(numeEv)) return;

            var evenimentAles = rezultate.Find(e => e.Nume.Equals(numeEv, StringComparison.OrdinalIgnoreCase));

            if (evenimentAles != null)
            {
                Console.Write("Tip bilet (ex: VIP): ");
                string tip = Console.ReadLine() ;

                if (evenimentAles.VindeBilet(tip, _numeLogat))
                {
                    _repo.Update(evenimentAles);
                    Console.WriteLine(" Succes! Biletul e la 'Biletele Mele'.");
                    _logger.LogInformation("{User} a cumparat {Bilet} la {Event}", _numeLogat, tip, evenimentAles.Nume);
                }
                else Console.WriteLine(" Eroare: Nu sunt locuri sau tipul e gresit.");
            }
        }

        private void BileteleMele()
        {
            Console.WriteLine($"\n Portofel bilete: {_numeLogat} ");
            var list = _repo.GetAll();
            bool amBilete = false;

            foreach (var ev in list)
            {
                var bileteleMele = ev.BileteVandute.Where(b => b.Proprietar == _numeLogat).ToList();

                if (bileteleMele.Count > 0 && ev.Status == "Programat")
                {
                    amBilete = true;
                    Console.WriteLine($"Eveniment: {ev.Nume} ({ev.Data:dd/MM})");
                    foreach (var b in bileteleMele)
                    {
                        Console.WriteLine($"  -> ID: {b.Id} | {b.Tip} | {b.Pret} RON");
                    }
                }
            }

            if (!amBilete) 
            {
                Console.WriteLine("Nu ai bilete active.");
                return; 
            }

            Console.WriteLine("\nGestionare:");
            Console.Write("Introdu ID-ul biletului pentru anulare [sau Enter pentru iesire]: ");
            string idBilet = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(idBilet))
            {
                bool sters = false;
                foreach(var ev in list)
                {
                    if (ev.ReturneazaBilet(idBilet, _numeLogat))
                    {
                        _repo.Update(ev);
                        Console.WriteLine(" Bilet anulat! Banii au fost returnati.");
                        _logger.LogWarning("{User} a anulat biletul {Id}", _numeLogat, idBilet);
                        sters = true;
                        break;
                    }
                }
                if (!sters) Console.WriteLine(" ID incorect sau biletul nu iti apartine.");
            }
        }

        
        private void IstoricTrecut()
        {
            Console.WriteLine("\n Istoric participari ");
            var list = _repo.GetAll();
            bool gasit = false;
            foreach(var ev in list)
            {
                if(ev.Data < DateTime.Now)
                {
                     var bileteVechi = ev.BileteVandute.Where(b => b.Proprietar == _numeLogat).ToList();
                     if(bileteVechi.Count > 0)
                     {
                         Console.WriteLine($"- {ev.Nume} ({ev.Data:dd/MM/yyyy}) - {bileteVechi.Count} bilete");
                         gasit = true;
                     }
                }
            }
            if(!gasit) Console.WriteLine("Nu ai istoric.");
        }
    }
}