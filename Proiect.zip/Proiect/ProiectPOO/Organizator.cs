namespace ProiectPOO
{
    public class Organizator : Utilizator
    {
        
        public Organizator(string nume, string email, string parola) 
            : base(nume, email, parola, "Organizator")
        {
        }
    }
}