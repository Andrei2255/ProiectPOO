namespace ProiectPOO
{
    public class Utilizator
    {
        public string Nume { get; init; }
        public string Email { get; init; }
        public string Parola { get; init; }
        public string Rol { get; init; } 

        public Utilizator(string nume, string email, string parola, string rol)
        {
            Nume = nume;
            Email = email;
            Parola = parola;
            Rol = rol;
        }
    }
}