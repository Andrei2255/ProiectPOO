using Microsoft.Extensions.Logging;

namespace ProiectPOO
{
    public class App
    {
        private readonly OrganizatorService _orgService;
        private readonly ClientService _clientService;
        private readonly ILogger<App> _logger;

        
        private List<Utilizator> _utilizatori = new List<Utilizator>()
        {
            new Utilizator("AdminExemplu", "admin", "admin123", "Organizator"),
            new Utilizator("Student1", "client", "1234", "Client")
        };

        private Utilizator _utilizatorCurent = null;

        public App(OrganizatorService orgService, ClientService clientService, ILogger<App> logger)
        {
            _orgService = orgService;
            _clientService = clientService;
            _logger = logger;
        }

        public void Run()
        {
            _logger.LogInformation("Aplicatia a pornit.");

            while (true)
            {
                Console.Clear();
                Console.WriteLine(" Sistem Evenimente (Login) ");
                
                
                if (_utilizatorCurent == null)
                {
                    Console.WriteLine("1. Autentificare");
                    Console.WriteLine("0. Iesire");
                    Console.Write("Optiune: ");
                    
                    var opt = Console.ReadLine();
                    if (opt == "0") break;
                    if (opt == "1") Login();
                }
                else
                {
                    
                    Console.WriteLine($"\nBine ai venit, {_utilizatorCurent.Nume}!");
                    
                    try 
                    {
                        if (_utilizatorCurent.Rol == "Organizator")
                        {
                            _orgService.Meniu(); 
                        }
                        else if (_utilizatorCurent.Rol == "Client")
                        {
                            
                            _clientService.Meniu(_utilizatorCurent.Nume);
                        }
                        
                        
                        _utilizatorCurent = null; 
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Eroare in meniu.");
                        Console.WriteLine("Eroare . Apasa Enter.");
                        Console.ReadLine();
                        _utilizatorCurent = null; 
                    }
                }
            }
        }

        private void Login()
        {
            Console.WriteLine("\n Autentificare ");
            Console.Write("User/Email: ");
            string email = Console.ReadLine();
            
            Console.Write("Parola: ");
            string pass = Console.ReadLine();

            
            var userGasit = _utilizatori.Find(u => u.Email == email && u.Parola == pass);

            if (userGasit != null)
            {
                _utilizatorCurent = userGasit;
                _logger.LogInformation("Logare cu succes: {Nume}", userGasit.Nume);
            }
            else
            {
                Console.WriteLine("Date incorecte! Incearca din nou.");
                Console.ReadLine();
            }
        }
    }
}