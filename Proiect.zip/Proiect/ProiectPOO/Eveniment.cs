namespace ProiectPOO
{
    public class Bilet
    {
        public string Id { get; init; } = Guid.NewGuid().ToString().Substring(0, 6);
        public string Tip { get; init; }
        public decimal Pret { get; init; }
        public string Proprietar { get; init; }
        public DateTime Data { get; init; } = DateTime.Now;
    }

    public class Eveniment
    {
        public string Nume { get; init; }
        public string Locatie { get; init; }
        public DateTime Data { get; init; }
        public string Status { get; private set; } = "Programat";

        public List<TipBilet> TipuriBilete { get; init; } = new List<TipBilet>();
        public List<Bilet> BileteVandute { get; init; } = new List<Bilet>();

        public Eveniment() { }

        public Eveniment(string nume, string loc, DateTime data)
        {
            Nume = nume;
            Locatie = loc;
            Data = data;
        }

        public void AdaugaTipBilet(string nume, decimal pret, int total)
        {
            TipuriBilete.Add(new TipBilet(nume, pret, total));
        }

        public bool VindeBilet(string numeTip, string numeCumparator)
        {
            if (Status != "Programat") return false;

            var tip = TipuriBilete.FirstOrDefault(t => t.Nume.Equals(numeTip, StringComparison.OrdinalIgnoreCase));

            if (tip != null && tip.VindeUnLoc())
            {
                var biletNou = new Bilet
                {
                    Tip = tip.Nume,
                    Pret = tip.Pret,
                    Proprietar = numeCumparator
                };
                BileteVandute.Add(biletNou);
                return true;
            }
            return false;
        }

        public bool ReturneazaBilet(string idBilet, string numeSolicitant)
        {
            var bilet = BileteVandute.FirstOrDefault(b => b.Id == idBilet && b.Proprietar == numeSolicitant);

            if (bilet != null)
            {
                BileteVandute.Remove(bilet);
                var tip = TipuriBilete.FirstOrDefault(t => t.Nume == bilet.Tip);

                if (tip != null) tip.ElibereazaUnLoc();

                return true;
            }
            return false;
        }

        public void AnuleazaEveniment()
        {
            Status = "Anulat";
        }

        public override string ToString() => $"{Nume} [{Status}] - {Data:dd/MM/yyyy} @ {Locatie}";
    }
}