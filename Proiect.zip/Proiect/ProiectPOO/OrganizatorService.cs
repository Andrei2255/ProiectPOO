using Microsoft.Extensions.Logging;

namespace ProiectPOO
{
    public class OrganizatorService
    {
        private readonly IEventRepository _repo;
        private readonly ILogger<OrganizatorService> _logger;

        public OrganizatorService(IEventRepository repo, ILogger<OrganizatorService> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        public void Meniu()
        {
            while (true)
            {
                Console.WriteLine("\nMeniu organizator");
                Console.WriteLine("1. Adauga Eveniment (si bilete)");
                Console.WriteLine("2. Gestioneaza Evenimente (Anulare/Raport)");
                Console.WriteLine("0. Inapoi");
                Console.Write("Optiune: ");
                
                string optiune = Console.ReadLine() ;

                if (optiune == "0") break;
                else if (optiune == "1") Adauga();
                else if (optiune == "2") Gestioneaza();
                else Console.WriteLine("Optiune invalida!");
            }
        }

        private void Adauga()
        {
            Console.WriteLine("\n Adaugare eveniment nou ");
            Console.Write("Nume eveniment: ");
            string nume = Console.ReadLine() ;

            Console.Write("Locatie: ");
            string loc = Console.ReadLine();

            Console.Write("Data (yyyy-mm-dd) [Enter pentru azi + 10 zile]: ");
            string dataStr = Console.ReadLine() ;
            DateTime data = DateTime.TryParse(dataStr, out var dt) ? dt : DateTime.Now.AddDays(10);

            var ev = new Eveniment(nume, loc, data);

            
            while (true)
            {
                Console.WriteLine("\nAdauga tip bilet (ex: VIP, Standard). Lasati gol pentru a termina.");
                Console.Write("Nume Bilet: ");
                string tip = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(tip)) break;

                Console.Write($"Pret pentru {tip}: ");
                decimal.TryParse(Console.ReadLine() , out decimal pret);

                Console.Write($"Numar total locuri {tip}: ");
                int.TryParse(Console.ReadLine() , out int stoc);

                if (pret > 0 && stoc > 0)
                {
                    ev.AdaugaTipBilet(tip, pret, stoc);
                    Console.WriteLine($"-> Adaugat: {tip} ({pret} RON) - {stoc} buc.");
                }
                else
                {
                    Console.WriteLine("Eroare: Pretul si stocul trebuie sa fie pozitive.");
                }
            }

            _repo.Add(ev);
            Console.WriteLine("Eveniment salvat cu succes!");
            _logger.LogInformation("Organizatorul a creat evenimentul: {Nume}", nume);
        }

        private void Gestioneaza()
        {
            Console.WriteLine("\n Lista evenimente ");
            var list = _repo.GetAll();
            if (list.Count == 0)
            {
                Console.WriteLine("Nu exista evenimente.");
                return;
            }

            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {list[i]}");
                foreach (var b in list[i].TipuriBilete)
                {
                     Console.WriteLine($"   - {b}");
                }
            }

            Console.Write("\nSelectati numarul evenimentului pentru anulare (sau 0 pentru inapoi): ");
            string input = Console.ReadLine() ;

            if (int.TryParse(input, out int idx) && idx > 0 && idx <= list.Count)
            {
                var ev = list[idx - 1];
                Console.Write($"Sigur anulati '{ev.Nume}'? (da/nu): ");
                if (Console.ReadLine() .ToLower() == "da")
                {
                    ev.AnuleazaEveniment();
                    _repo.Update(ev);
                    Console.WriteLine("Evenimentul a fost anulat.");
                    _logger.LogWarning("Organizatorul a anulat evenimentul {Nume}", ev.Nume);
                }
            }
        }
    }
}